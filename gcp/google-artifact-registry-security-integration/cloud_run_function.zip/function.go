package function

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"regexp"
	"strings"

	"github.com/GoogleCloudPlatform/functions-framework-go/functions"
	"github.com/cloudevents/sdk-go/v2/event"
	"golang.org/x/oauth2/google"
)

var (
	// Authenticated HTTP client cached at package level (reused across requests).
	httpClient       *http.Client
	resourceURIRegex = regexp.MustCompile(
		`^https://(.+)-docker\.pkg\.dev/([^/]+)/([^/]+)/([^@]+)@(.+)$`,
	)
)

func init() {
	slog.SetDefault(slog.New(slog.NewJSONHandler(os.Stderr, &slog.HandlerOptions{
		Level: slog.LevelDebug,
	})))

	ctx := context.Background()
	var err error
	httpClient, err = google.DefaultClient(ctx, "https://www.googleapis.com/auth/cloud-platform")
	if err != nil {
		slog.Error("Failed to create authenticated HTTP client", "error", err)
		os.Exit(1)
	}

	functions.CloudEvent("process_occurrence", processOccurrence)
}

// MessagePublishedData is the payload of a google.cloud.pubsub.topic.v1.messagePublished event.
type MessagePublishedData struct {
	Message PubSubMessage `json:"message"`
}

// PubSubMessage is the inner Pub/Sub message.
type PubSubMessage struct {
	Data string `json:"data"`
}

func processOccurrence(ctx context.Context, e event.Event) error {
	var msg MessagePublishedData
	if err := e.DataAs(&msg); err != nil {
		return fmt.Errorf("event.DataAs: %w", err)
	}

	// 1. Decode the Pub/Sub message data
	pubsubData, err := base64.StdEncoding.DecodeString(msg.Message.Data)
	if err != nil {
		return fmt.Errorf("base64 decode: %w", err)
	}
	slog.Debug("Raw pubsub_data", "data", string(pubsubData))

	var notification map[string]any
	if err := json.Unmarshal(pubsubData, &notification); err != nil {
		return fmt.Errorf("json unmarshal notification: %w", err)
	}
	notifJSON, _ := json.MarshalIndent(notification, "", "  ")
	slog.Info("Received notification", "notification", string(notifJSON))

	// 2. Early filter: skip non-VULNERABILITY occurrences before making any API call
	if kind, ok := notification["kind"].(string); ok && kind != "" && kind != "VULNERABILITY" {
		slog.Info("Skipping non-vulnerability occurrence", "kind", kind)
		return nil
	}

	// 3. Extract the occurrence resource name
	occurrenceName, _ := notification["name"].(string)
	if occurrenceName == "" {
		slog.Warn("No occurrence name found in notification, skipping")
		return nil
	}

	// 4. Fetch full occurrence details from Container Analysis API
	apiURL := fmt.Sprintf("https://containeranalysis.googleapis.com/v1/%s", occurrenceName)
	resp, err := httpClient.Get(apiURL)
	if err != nil {
		return fmt.Errorf("container analysis API call: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("reading response body: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("container analysis API returned %d: %s", resp.StatusCode, body)
	}

	var occurrence map[string]any
	if err := json.Unmarshal(body, &occurrence); err != nil {
		return fmt.Errorf("json unmarshal occurrence: %w", err)
	}
	occJSON, _ := json.MarshalIndent(occurrence, "", "  ")
	slog.Debug("Occurrence details", "occurrence", string(occJSON))

	if kind, _ := occurrence["kind"].(string); kind == "VULNERABILITY" {
		// 5. Enrich with container image tags from Artifact Registry
		if resourceURI, _ := occurrence["resourceUri"].(string); resourceURI != "" {
			tags := resolveImageTags(resourceURI)
			occurrence["container_image.tags"] = tags
			slog.Info("Resolved image tags", "tags", tags)
		}

		// 6. Send occurrence data to Dynatrace
		if err := sendToDynatrace(occurrence); err != nil {
			return err
		}
	} else {
		slog.Info("Occurrence will not be ingested", "kind", occurrence["kind"])
	}

	return nil
}

// resolveImageTags queries the Artifact Registry API to find tags matching the digest
// in the given resourceUri (e.g. https://LOCATION-docker.pkg.dev/PROJECT/REPO/IMAGE@sha256:DIGEST).
func resolveImageTags(resourceURI string) []string {
	matches := resourceURIRegex.FindStringSubmatch(resourceURI)
	if matches == nil {
		slog.Warn("Could not parse resourceUri for tag lookup", "resourceUri", resourceURI)
		return nil
	}

	location := matches[1]
	project := matches[2]
	repo := matches[3]
	image := matches[4]
	digest := matches[5]

	arURL := fmt.Sprintf(
		"https://artifactregistry.googleapis.com/v1/projects/%s/locations/%s/repositories/%s/packages/%s/tags",
		project, location, repo, image,
	)

	resp, err := httpClient.Get(arURL)
	if err != nil {
		slog.Error("Failed to list tags from Artifact Registry", "error", err)
		return nil
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		slog.Error("Failed to read Artifact Registry response", "error", err)
		return nil
	}
	if resp.StatusCode != http.StatusOK {
		slog.Error("Artifact Registry API error", "statusCode", resp.StatusCode, "body", string(body))
		return nil
	}

	var tagsData struct {
		Tags []struct {
			Name    string `json:"name"`
			Version string `json:"version"`
		} `json:"tags"`
	}
	if err := json.Unmarshal(body, &tagsData); err != nil {
		slog.Error("Failed to parse tags response", "error", err)
		return nil
	}
	slog.Debug("Tag data from Artifact Registry", "tags", string(body))

	var tags []string
	for _, tag := range tagsData.Tags {
		if strings.HasSuffix(tag.Version, digest) {
			parts := strings.Split(tag.Name, "/")
			tagName := parts[len(parts)-1]
			tags = append(tags, tagName)
		}
	}

	return tags
}

// sendToDynatrace posts the occurrence JSON to the Dynatrace Security Events OpenPipeline API.
func sendToDynatrace(occurrence map[string]any) error {
	dtAPIToken := strings.TrimSpace(os.Getenv("DT_API_TOKEN"))
	dtBaseURL := os.Getenv("DT_BASE_URL")
	gcpOrgID := os.Getenv("GCP_ORG_ID")
	gcpOrgName := os.Getenv("GCP_ORG_NAME")

	if dtAPIToken == "" || dtBaseURL == "" {
		slog.Warn("DT_API_TOKEN or DT_BASE_URL environment variable not set, skipping Dynatrace ingest")
		return nil
	}

	if gcpOrgID != "" || gcpOrgName != "" {
		occurrence["gcp.organization.id"] = gcpOrgID
		occurrence["gcp.organization.name"] = gcpOrgName
	}

	url := strings.TrimRight(dtBaseURL, "/") + "/platform/ingest/v1/security.events"

	payload, err := json.Marshal(occurrence)
	if err != nil {
		return fmt.Errorf("json marshal occurrence: %w", err)
	}
	slog.Debug("Sending to Dynatrace", "url", url, "payload", string(payload))

	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(payload))
	if err != nil {
		return fmt.Errorf("create dynatrace request: %w", err)
	}
	req.Header.Set("Authorization", "Bearer "+dtAPIToken)
	req.Header.Set("Content-Type", "application/json")

	// Use default client (no GCP auth needed for Dynatrace)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return fmt.Errorf("dynatrace API call: %w", err)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		slog.Info("Dynatrace ingest successful", "statusCode", resp.StatusCode)
	} else {
		return fmt.Errorf("dynatrace ingest failed: %d - %s", resp.StatusCode, respBody)
	}

	return nil
}

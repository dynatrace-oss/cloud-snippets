import json
import logging
import os

import azure.functions as func
import requests

app = func.FunctionApp()


@app.event_hub_message_trigger(
    arg_name="azeventhub",
    event_hub_name="dt-appsec-event-hub",
    connection="EventHubConnectionString",
)
def eventhub_trigger(azeventhub: func.EventHubEvent):
    logging.info(
        "Custom - Python EventHub trigger processed an event: %s",
        azeventhub.get_body().decode("utf-8"),
    )

    event_body = azeventhub.get_body().decode("utf-8")
    event_json = json.loads(event_body)
    if "records" in event_json.keys():
        for record in event_json["records"]:
            ingest_event_for_records(record)
    else:
        ingest_event_for_records(event_json)


def ingest_event_for_records(record: dict):
    payload = json.dumps([record])
    logging.info(f"Payload: {payload}")

    PostDynatraceEvent(payload)


def PostDynatraceEvent(payload):
    DT_API_URL = os.environ["DT_API_URL"]
    DT_TOKEN = os.environ["DT_TOKEN"]
    HEADERS = {
        "Authorization": "Api-Token " + DT_TOKEN,
        "Content-Type": "application/json; charset=utf-8",
    }
    logging.info(f"Using url = {DT_API_URL}")

    r = requests.post(DT_API_URL, data=payload, headers=HEADERS)
    logging.info(f"Request status: {r.status_code}")

    if not r.ok:
        logging.error(f"Request text: {r.text}")

<?php

echo "Hello from Dynatrace!";

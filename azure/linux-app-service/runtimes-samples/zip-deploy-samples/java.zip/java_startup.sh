#!/bin/sh

readonly installerWrapperinstallationPath=/tmp/installer-wrapper.sh
readonly installerWrapperURL=https://mjarzemb.blob.core.windows.net/mjarzemb-public/oneagent_installer.sh

wget -O $installerWrapperinstallationPath $installerWrapperURL
sh $installerWrapperinstallationPath

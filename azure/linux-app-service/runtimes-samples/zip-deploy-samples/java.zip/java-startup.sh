#!/bin/sh

readonly installerWrapperInstallationPath=/tmp/installer-wrapper.sh
readonly installerWrapperURL=https://mjarzemb.blob.core.windows.net/mjarzemb-public/oneagent-installer.sh

wget -O $installerWrapperInstallationPath -q $installerWrapperURL
sh $installerWrapperInstallationPath
